/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

union class 
{
    int Rollno;
    char name;
};
int main()
{
    union class a, *a1;
    a1 = &a;
    a1->Rollno = 85; 
    a1->name = 'J';  
    printf("%d %c\n", a1->Rollno, a1->name); 
    printf("Size of struct class: %lu bytes\n", sizeof(union class));
    return 0;
}
