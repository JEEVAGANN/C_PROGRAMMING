/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
struct class
{
    int Rollno;
    char name;
};
int main()
{
    struct class a;
    a.Rollno=85;
    a.name='J';
    printf("%d %c",a.Rollno,a.name);
}